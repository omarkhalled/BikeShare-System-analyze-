https://stackoverflow.com/questions/43772362/how-to-print-a-specific-row-of-a-pandas-dataframe
https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.filter.html
https://www.codegrepper.com/code-examples/python/python+stop+program+if+condition
https://www.javascripttutorial.net/javascript-return-multiple-values/
https://www.kite.com/python/answers/how-to-print-a-float-with-two-decimal-places-in-python#:~:text=Use%20str.,string%20to%20print%20the%20float.
https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.apply.html
