## BikeShare system to analyze data and answer a lot of important quesions
#import all necessary packages and functions.
import time
import pandas as pd
##intialize Variables
CITY_DATA = { 'chicago': 'chicago.csv',
              'new york': 'new_york_city.csv',
              'washington': 'washington.csv' }
cities = ['chicago','new york','washington']
months = ['january', 'february', 'march', 'april', 'may', 'june']
days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday','sunday']
def greating_message():
    """start the system by grearing message and some instructions"""
    
    print('Hello! \nLet\'s explore some US bikeshare data!')
    print('follow this instructions below\n')
    print('To achieve the maximum value from this system\nspecify what you need carefuly')
    print('#Note at any point\n_to restart : \'restart\'\n_to close : type \'close\'\n')
    
def get_filters():

    """
    Asks user to specify a city, month, and day to analyze.
    
    Returns:
        (str) option - if user want to restart or close the system
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    # intialize our variables
    city = month = day = option = 'Null'
    # printin greating message and give the instructions to the user
    greating_message()
    while True :
            
        # get user input for city (chicago, new york city, washington)
        try :
            city = input('Would you like to analyze data for Chicago, New York, or Washington?\n').lower().strip()
            # check if user want to restart or close
            if city == 'restart' :
                option = city
                return option,city, month, day
            if city == 'close' :
                option = city
                return option,city, month, day
            
            if city not in cities :
                print('* warnin please type one of it Chicago, New York, or Washington *\n')
                continue 
            show = input("Before filter data if you would like to see the first 5 row of data type \'yes\'\nif no type anything\n").lower().strip()
            if show =='yes' :
                counter = 5
                current = 0
                df = pd.read_csv(CITY_DATA[city])
                index = df.index
                number_of_rows = len(index)
                while counter < number_of_rows and show =='yes':
                    print(df.iloc[current:counter])
                    show = input("would you like to see 5 more ? \n").lower().strip()
                    current = counter
                    counter += 5
                
            # get user input for month (all, january, february, ... , june)
            choice = input('Would you like to filter the data by month, day, or not at all?\n#type \'no\' for no filter\n').lower().strip()
            # check if user want to restart or close
            if choice == 'restart' :
                option = choice
                return option,city, month, day
            if choice == 'close' :
                option = choice
                return option,city, month, day
            # get user input for day of week (all, monday, tuesday, ... sunday)
            day = month = 'all'
            if choice == 'day' :
                 day = input('Which day - Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, or Sunday?\n').lower().strip()
                 
                 if day == 'restart' :
                    option = day
                    return option,city, month, day
                 if day == 'close' :
                     option = day
                     return option,city, month, day
                 if day not in days :
                     print('* Warning please type valid day name *\n')
                     continue 
            elif choice == 'month' :
                 month = input('Which month - January, February, March, April, May, or June?\n').lower().strip()
                 # check if user want to restart or close
                 if month == 'restart' :
                     option = month
                     return option,city, month, day
                 if month == 'close' :
                     option = month
                     return option,city, month, day
                 if month not in months :
                     print('* Warning please type valid month name of first 6 months *\n')
                     continue 
            elif choice == 'no' :         
                 day = month = 'all'
            else :
                print("* Warning please type valid choice *\n")
                continue
        except :
            print("* Warning please type valid input *\n")
        break 
        
    print('-'*40)
    return option,city, month, day

def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    # Loads data for the specified city
    df = pd.read_csv(CITY_DATA[city])
    # convert time to date time to extract the month and day
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['End Time'] = pd.to_datetime(df['End Time'])
    # extract day and month and create new columns
    df['Month'] = df['End Time'].dt.month_name()
    df['Day'] = df['End Time'].dt.day_name()
  
    if month !='all':
        return df[df['Month']==month.title()]
    elif day !='all' :
        return df[df['Day']==day.title()]      
    else :
        return df

def time_stats(df,month,day):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    if month == 'all' :
        print('The most common month to travel is {}\n'.format(df['Month'].mode()[0]))

    # display the most common day of week
    if day == 'all' :
        print('The most common day to travel is {}\n'.format(df['Day'].mode()[0]))

    # display the most common start hour
    print('The most common hour to travel is {}\n'.format(df['Start Time'].dt.hour.mode()[0]))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    print('The most common start stations is {}\n'.format(df['Start Station'].mode()[0]))
    
    # display most commonly used end station
    print('The most common end stations is {}\n'.format(df['End Station'].mode()[0]))

    # display most frequent combination of start station and end station trip
    print('The most frequent trip is from {}\n'.format((df['Start Station'] + ' to ' + df['End Station']).mode()[0]))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    total_time = df['Trip Duration'].sum()
    # convert total time from seconds to hours 
    total_time /= 3600
    average_time = df['Trip Duration'].mean()
    # convert average time from seconds to minutes 
    average_time /=60
    # display total travel time
    print('The total trip duration is {:.2f} hours \n'.format(total_time))
    # display mean travel time
    print('The Average trip duration is {:.2f} minutes \n'.format(average_time))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def user_stats(df,city):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    print(df['User Type'].value_counts())
    
    if city != 'washington' :
        # Display counts of gender
        
        print(df['Gender'].value_counts())
    
        # Display earliest, most recent, and most common year of birth
        print('The earliest year of birth of users is {} '.format(int(df['Birth Year'].min())))
        print('The most recent year of birth of users is {} '.format(int(df['Birth Year'].max())))
        print('The most common year of birth of users is {} '.format(int(df['Birth Year'].mode()[0])))
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
    
def main():

    while True :
        
        option, city, month, day = get_filters()
        if option =='restart' :
            continue
        if option =='close' :
            break
        df = load_data(city, month, day)
        time_stats(df,month,day)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df,city)
        try :
            flag = input('Would you like to start again ??\n_to start again : type anything\n_to close : type \'close\'\n').lower().strip()
            if(flag=='close') :
                 break
        except :
            print('* Warning please type valid input *')
        
if __name__ == "__main__":
	main()